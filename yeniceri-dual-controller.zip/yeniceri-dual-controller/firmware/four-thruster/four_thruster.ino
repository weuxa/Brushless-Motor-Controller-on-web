#include <Arduino.h>
#include <ESP32Servo.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// =====================================================
// YENICERI-4T — 4 iticili denizalti firmware'i
// Web: /submarine/  |  Komut: M,left,right,vertical
// =====================================================
#define DEVICE_NAME "Yeniceri-4T"
#define SERVICE_UUID "12345678-1234-1234-1234-1234567890ab"
#define CHARACTERISTIC_UUID "12345678-1234-1234-1234-1234567890ac"

// Bu sistemde ileri/geri ve yerinde dönme için çift yonlu ESC gerekir.
// ESC'nin 1500 us nötr/reverse desteklediğini doğrulamadan bataryayı bağlama.
#define BIDIRECTIONAL_ESC true

// Kart pinleri — gerçek Deneyap pin eşlemeni kontrol et.
#define REAR_LEFT_PIN  D0
#define REAR_RIGHT_PIN D1
#define FRONT_LEFT_PIN D2
#define FRONT_RIGHT_PIN D3

const int ESC_MIN_US = 1000;
const int ESC_NEUTRAL_US = 1500;
const int ESC_MAX_US = 2000;
const int MAX_POWER = 100;
const unsigned long COMMAND_TIMEOUT_MS = 1200; // Sayfa her 300 ms'de H yollar.
const unsigned long ESC_STARTUP_MS = 3000;

Servo rearLeftESC, rearRightESC, frontLeftESC, frontRightESC;
BLECharacteristic *characteristic = nullptr;
volatile bool deviceConnected = false;
volatile bool stopRequested = true;
volatile int rearLeftPower = 0;
volatile int rearRightPower = 0;
volatile int verticalPower = 0;
volatile unsigned long lastValidPacketMs = 0;

int stopPulseUs() {
  return BIDIRECTIONAL_ESC ? ESC_NEUTRAL_US : ESC_MIN_US;
}

void stopMotors() {
  rearLeftPower = 0;
  rearRightPower = 0;
  verticalPower = 0;
  stopRequested = true;
}

void writeAllStopped() {
  const int p = stopPulseUs();
  rearLeftESC.writeMicroseconds(p);
  rearRightESC.writeMicroseconds(p);
  frontLeftESC.writeMicroseconds(p);
  frontRightESC.writeMicroseconds(p);
}

int powerToPulse(int power) {
  power = constrain(power, -MAX_POWER, MAX_POWER);
  if (!BIDIRECTIONAL_ESC) {
    // Tek yonlu ESC modunda negatif komut duruş sayılır; geri gitmez.
    if (power <= 0) return ESC_MIN_US;
    return map(power, 1, MAX_POWER, 1050, ESC_MAX_US);
  }
  if (power > 0) return map(power, 1, MAX_POWER, 1520, ESC_MAX_US);
  if (power < 0) return map(power, -1, -MAX_POWER, 1480, ESC_MIN_US);
  return ESC_NEUTRAL_US;
}

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *server) override {
    deviceConnected = true;
    lastValidPacketMs = millis();
    stopMotors();
    Serial.println("Yeniceri-4T BLE baglandi; motorlar durusta.");
  }
  void onDisconnect(BLEServer *server) override {
    deviceConnected = false;
    stopMotors();
    Serial.println("BLE kesildi; loop guvenli durusa geciyor.");
    BLEDevice::startAdvertising();
  }
};

class CommandCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *c) override {
    String command = c->getValue().c_str();
    command.trim();
    lastValidPacketMs = millis();

    if (command == "S") {
      stopMotors();
      Serial.println("STOP");
      return;
    }
    if (command == "H") return; // heartbeat: aktif hareketi koru

    if (!command.startsWith("M,")) {
      stopMotors();
      Serial.println("Bilinmeyen komut -> STOP");
      return;
    }

    int c1 = command.indexOf(',');
    int c2 = command.indexOf(',', c1 + 1);
    int c3 = command.indexOf(',', c2 + 1);
    if (c1 < 0 || c2 < 0 || c3 < 0) {
      stopMotors();
      Serial.println("Hatali M komutu -> STOP");
      return;
    }

    int left = command.substring(c1 + 1, c2).toInt();
    int right = command.substring(c2 + 1, c3).toInt();
    int vertical = command.substring(c3 + 1).toInt();
    rearLeftPower = constrain(left, -MAX_POWER, MAX_POWER);
    rearRightPower = constrain(right, -MAX_POWER, MAX_POWER);
    verticalPower = constrain(vertical, -MAX_POWER, MAX_POWER);
    stopRequested = false;

    Serial.printf("Komut L:%d R:%d V:%d\n", rearLeftPower, rearRightPower, verticalPower);
  }
};

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("Yeniceri-4T basliyor...");

  rearLeftESC.setPeriodHertz(50);
  rearRightESC.setPeriodHertz(50);
  frontLeftESC.setPeriodHertz(50);
  frontRightESC.setPeriodHertz(50);

  rearLeftESC.attach(REAR_LEFT_PIN, ESC_MIN_US, ESC_MAX_US);
  rearRightESC.attach(REAR_RIGHT_PIN, ESC_MIN_US, ESC_MAX_US);
  frontLeftESC.attach(FRONT_LEFT_PIN, ESC_MIN_US, ESC_MAX_US);
  frontRightESC.attach(FRONT_RIGHT_PIN, ESC_MIN_US, ESC_MAX_US);

  writeAllStopped();
  Serial.printf("ESC durus sinyali: %d us\n", stopPulseUs());
  delay(ESC_STARTUP_MS);

  BLEDevice::init(DEVICE_NAME);
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService *service = server->createService(SERVICE_UUID);
  characteristic = service->createCharacteristic(
    CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_READ |
    BLECharacteristic::PROPERTY_WRITE |
    BLECharacteristic::PROPERTY_WRITE_NR |
    BLECharacteristic::PROPERTY_NOTIFY
  );
  characteristic->setCallbacks(new CommandCallbacks());
  characteristic->addDescriptor(new BLE2902());
  characteristic->setValue("READY");
  service->start();
  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.println("BLE hazir. Cihaz: Yeniceri-4T");
}

void loop() {
  if (!deviceConnected) {
    stopMotors();
    writeAllStopped();
    delay(20);
    return;
  }

  if (millis() - lastValidPacketMs > COMMAND_TIMEOUT_MS) {
    stopMotors();
  }

  if (stopRequested) {
    writeAllStopped();
    delay(20);
    return;
  }

  int left = rearLeftPower;
  int right = rearRightPower;
  int vertical = verticalPower;
  rearLeftESC.writeMicroseconds(powerToPulse(left));
  rearRightESC.writeMicroseconds(powerToPulse(right));
  frontLeftESC.writeMicroseconds(powerToPulse(vertical));
  frontRightESC.writeMicroseconds(powerToPulse(vertical));
  delay(20);
}
