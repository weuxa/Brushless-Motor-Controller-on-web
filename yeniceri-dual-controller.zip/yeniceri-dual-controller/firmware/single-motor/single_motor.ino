#include <Arduino.h>
#include <ESP32Servo.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// =====================================================
// Brushless-Motor-1T — sade tek motor firmware'i
// Web: /single-motor/ | Komut: M,speed,0,0 / S / H
// Tek yonlu ESC varsayimi: 1000 us stop, 1000-2000 us throttle.
// =====================================================
#define DEVICE_NAME "Brushless-Motor-1T"
#define SERVICE_UUID "12345678-1234-1234-1234-1234567890ab"
#define CHARACTERISTIC_UUID "12345678-1234-1234-1234-1234567890ac"

#define MOTOR_PIN D0 // Tek ESC sinyal pinini kart bağlantına göre doğrula.
// Tek yönlü ESC için false (1000 us stop); çift yönlü ESC için true (1500 us neutral).
// ESC'nin gerçek modunu doğrulamadan ayarı değiştirme.
#define ESC_BIDIRECTIONAL false
const int ESC_STOP_US = 1000;
const int ESC_NEUTRAL_US = 1500;
const int ESC_MAX_US = 2000;
const int MAX_POWER = 100;
const unsigned long COMMAND_TIMEOUT_MS = 1200;
const unsigned long ESC_STARTUP_MS = 3000;

Servo motorESC;
BLECharacteristic *characteristic = nullptr;
volatile bool deviceConnected = false;
volatile bool stopRequested = true;
volatile int motorPower = 0;
volatile unsigned long lastValidPacketMs = 0;

void stopMotor() {
  motorPower = 0;
  stopRequested = true;
}

int stopPulseUs() {
  return ESC_BIDIRECTIONAL ? ESC_NEUTRAL_US : ESC_STOP_US;
}

void writeStop() {
  motorESC.writeMicroseconds(stopPulseUs());
}

int powerToPulse(int power) {
  power = constrain(power, 0, MAX_POWER);
  if (power == 0) return stopPulseUs();
  if (ESC_BIDIRECTIONAL) {
    // Tek yönlü UI: sadece nötrden ileri gaza çıkar, geri komutu yollamaz.
    return map(power, 1, MAX_POWER, 1520, ESC_MAX_US);
  }
  return map(power, 1, MAX_POWER, 1010, ESC_MAX_US);
}

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer *server) override {
    deviceConnected = true;
    lastValidPacketMs = millis();
    stopMotor();
    Serial.println("Tek motor BLE baglandi; motor durusta.");
  }
  void onDisconnect(BLEServer *server) override {
    deviceConnected = false;
    stopMotor();
    Serial.println("BLE kesildi; motor durdurulacak.");
    BLEDevice::startAdvertising();
  }
};

class CommandCallbacks : public BLECharacteristicCallbacks {
  void onWrite(BLECharacteristic *c) override {
    String command = c->getValue().c_str();
    command.trim();
    lastValidPacketMs = millis();

    if (command == "S") {
      stopMotor();
      Serial.println("STOP");
      return;
    }
    if (command == "H") return; // heartbeat motor gücünü değiştirmez

    if (!command.startsWith("M,")) {
      stopMotor();
      Serial.println("Bilinmeyen komut -> STOP");
      return;
    }
    int c1 = command.indexOf(',');
    int c2 = command.indexOf(',', c1 + 1);
    int c3 = command.indexOf(',', c2 + 1);
    if (c1 < 0 || c2 < 0 || c3 < 0) {
      stopMotor();
      Serial.println("Hatali M komutu -> STOP");
      return;
    }

    // Bu firmware ilk kanalı kullanır: M,<speed>,0,0
    int requested = command.substring(c1 + 1, c2).toInt();
    motorPower = constrain(requested, 0, MAX_POWER);
    stopRequested = (motorPower == 0);
    Serial.printf("Motor guc istegi: %d%%\n", motorPower);
  }
};

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("Tek motor sistemi basliyor...");
  Serial.printf("ESC durus sinyali: %d us\n", stopPulseUs());

  motorESC.setPeriodHertz(50);
  motorESC.attach(MOTOR_PIN, ESC_STOP_US, ESC_MAX_US);
  writeStop();
  delay(ESC_STARTUP_MS);

  BLEDevice::init(DEVICE_NAME);
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService *service = server->createService(SERVICE_UUID);
  characteristic = service->createCharacteristic(
    CHARACTERISTIC_UUID,
    BLECharacteristic::PROPERTY_READ |
    BLECharacteristic::PROPERTY_WRITE |
    BLECharacteristic::PROPERTY_WRITE_NR |
    BLECharacteristic::PROPERTY_NOTIFY
  );
  characteristic->setCallbacks(new CommandCallbacks());
  characteristic->addDescriptor(new BLE2902());
  characteristic->setValue("READY");
  service->start();
  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.println("BLE hazir. Cihaz: Brushless-Motor-1T");
}

void loop() {
  if (!deviceConnected) {
    stopMotor();
    writeStop();
    delay(20);
    return;
  }
  if (millis() - lastValidPacketMs > COMMAND_TIMEOUT_MS) {
    stopMotor();
  }
  if (stopRequested || motorPower <= 0) {
    writeStop();
    delay(20);
    return;
  }
  motorESC.writeMicroseconds(powerToPulse(motorPower));
  delay(20);
}
